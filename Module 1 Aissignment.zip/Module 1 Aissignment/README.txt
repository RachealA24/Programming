Hello,

Kindly see below how to run the codes 

1.For Python(Racheal Ajayi Assignment) run using Jupiter notebooks.

2.For R code (Racheal Console) run using R Studio