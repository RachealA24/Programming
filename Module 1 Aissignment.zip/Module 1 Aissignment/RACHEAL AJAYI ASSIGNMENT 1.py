#!/usr/bin/env python
# coding: utf-8

# ## Create a list of workers with at least 400 workers dynamically 

# In[8]:


import random


# ## Step 2: Create a list of workers with at least 400 workers dynamically

# In[9]:


workers = []
for _ in range(400):
    worker = {
        'name': f'Worker{_ + 1}',
        'gender': random.choice(['Male', 'Female']),
        'salary': random.uniform(3000, 35000)
    }
    workers.append(worker)


# ## Step 3: Use a for loop to generate payment slips for each worker

# In[10]:


for worker in workers:
    try:
        # Step 4: Implement conditional statements
        if 10000 < worker['salary'] < 20000:
            worker['level'] = 'A1'
        elif 7500 < worker['salary'] < 30000 and worker['gender'] == 'Female':
            worker['level'] = 'A5-F'
        else:
            worker['level'] = 'A6'

        # Generate payment slip
        print(f"Payment Slip for {worker['name']} - Level: {worker['level']}, Salary: ${worker['salary']:.2f}")

    except Exception as e:
        print(f"Error processing payment slip for {worker['name']}: {e}")


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




